﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace demo_EFCORE_CodeFirstApproach_MVC.Migrations
{
    /// <inheritdoc />
    public partial class initmigration2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
